# BlockWise Trade Office

A 3D cyberpunk trading-bot office. Default view looks down on the floor like a
dashboard; clicking a bot, desk, the chart board, the clock, or the Command
Core zooms the camera in and opens the relevant panel.

## Run it

No build step needed.

**Quickest:** double-click `index.html` — it opens straight in your browser.

**If you want a local server** (nicer for testing on other devices on your
network, and needed if you later add ES modules or fetch() calls that some
browsers restrict on `file://`):

```bash
# from inside this folder
npx serve .
# or
python3 -m http.server 8080
```
then open the printed `localhost` URL.

**To share it on the web:** drag the folder into [Vercel](https://vercel.com)
or [Netlify Drop](https://app.netlify.com/drop) — both host static sites like
this for free with zero config.

## Project structure

```
BlockWiseTradeOffice/
├── index.html         # page shell, loads Three.js from CDN + local scripts
├── css/
│   └── style.css      # design tokens (colors/type) + all UI styling
└── js/
    ├── data.js         # bot roster, market hours, mock price/wallet data, event bus
    ├── scene.js         # Three.js office, robots, camera zoom/tween, raycasting clicks
    ├── ui.js            # HUD, minimizable panels, modals (bot profile, desk settings, etc.)
    └── main.js           # boot sequence (loading screen -> scene + UI init)
```

## What's already working

- Top-down "dashboard view" of the office with 5 named worker bots + BOSS BOT
  on a raised platform with a rotating holographic Command Core above it
- Click a **bot** → camera zooms in, opens that bot's profile (shift time,
  trades today, sales, P&L, work rate)
- Click a **desk** → zooms in, opens **role-level** settings (assign a
  worker, risk %, position size, trading pairs) — separate from the
  individual bot's own profile, as requested
- Click the **chart board** on the wall → live-updating price panel
  (BTC, ETH, SOL, gold, a meme coin)
- Click the **clock** → world market clock; green/red dots are computed from
  real local time in each market's timezone, not just placeholders
- Click the **Command Core** above BOSS BOT → floor-wide overview: total
  trades, net P&L, and a compliance readout per role (this is the "boss
  keeps everyone in line" mechanic)
- Persistent minimizable side panels for the price ticker and meme-coin
  alerts, similar to a real trading terminal
- Wallet button → connect Phantom / Coinbase / MetaMask (mocked), see
  balances, top up SOL/BTC/ETH/USDC (mocked, local only)
- "Return to office view" button appears whenever you're zoomed in

## Where things are simulated (and what to swap in later)

Everything here runs client-side with placeholder data so you can see and
feel the whole flow immediately. The intentional seams to come back to:

| Feature | Right now | Swap in |
|---|---|---|
| Prices (`js/data.js` → `PRICE_BOARD`) | random walk | [CoinGecko API](https://www.coingecko.com/en/api) for crypto, a metals API for gold |
| Wallet (`js/data.js` → `WALLET`) | local mock balances | [Solana wallet-adapter](https://github.com/anza-xyz/wallet-adapter) for Phantom, [wagmi](https://wagmi.sh)/ethers for MetaMask/Coinbase |
| Bot stats (`js/data.js` → `ROLES`) | hand-entered numbers | your bot backend / exchange API, polled on an interval |
| Meme alerts | static list | a real DEX screener / new-pair feed |

Market-hours logic in `isMarketOpen()` is **not** mocked — it computes real
open/closed status from the current time in each exchange's timezone.

## Extending it (this is meant to grow)

- **New bot role:** add an entry to `ROLES` in `data.js` (name, color, desk
  position, mission, worker stats) — the desk, bot model, legend entry, and
  profile modal all pick it up automatically.
- **New clickable object:** build the mesh in `scene.js`, tag it with
  `userData.type = 'yourType'` and push it into `interactables`, then handle
  that type in `handleClick()` and listen for the matching `Bus` event in
  `ui.js`.
- **Trading logic:** none of this touches real trading — it's the visual
  command center. Wire your actual bot engine to update `ROLES[i].worker`
  and `WALLET.balances` on an interval and the UI will reflect it.

## Best platform to build this further

- Keep prototyping visuals here (vanilla Three.js, no build step) as long as
  it's convenient.
- If/when this grows past a few files, moving to **Vite + vanilla or React
  Three Fiber** gives you hot reload, module bundling, and easier state
  management, while keeping the same Three.js concepts.
- For the wallet/trading backend, that logic belongs server-side (Node,
  or a serverless function) — never hold real private keys in a browser tab.
