/* =========================================================
   BLOCKWISE TRADE OFFICE — UI LAYER
   HUD stats, minimizable panels, and modals.
   ========================================================= */

const UI = (() => {

  const modalRoot = document.getElementById('modalRoot');
  const windowsContainer = document.getElementById('windowsContainer');
  const legendList = document.getElementById('legendList');
  const backBtn = document.getElementById('backToOfficeBtn');

  const ALL_ROLES = [...ROLES, BOSS];

  function fmtUSD(n){
    return (n<0?'-$':'$') + Math.abs(n).toLocaleString(undefined,{minimumFractionDigits:2, maximumFractionDigits:2});
  }

  // ---------------- HUD ----------------
  function refreshHUD(){
    const portfolio = ROLES.reduce((s,r)=>s + r.worker.salesToday, 0) + WALLET.totalUSD();
    const pnl = ROLES.reduce((s,r)=>s + r.worker.pnlToday, 0);
    document.getElementById('portfolioValue').textContent = fmtUSD(portfolio);
    const pnlEl = document.getElementById('pnlValue');
    pnlEl.textContent = (pnl>=0?'+':'') + fmtUSD(pnl);
    pnlEl.className = 'stat-chip-value ' + (pnl>=0?'stat-positive':'stat-negative');

    const activeCount = ROLES.filter(r=>r.worker.status==='ACTIVE').length;
    document.getElementById('activeBotsValue').textContent = `${activeCount}/${ROLES.length}`;

    document.getElementById('walletDot').className = 'dot' + (WALLET.connected ? ' on' : '');
  }

  // ---------------- legend ----------------
  function buildLegend(){
    legendList.innerHTML = ALL_ROLES.map(r => `
      <div class="legend-item" data-role="${r.id}">
        <span class="legend-swatch" style="background:${r.hex || '#'+r.color.toString(16)}"></span>
        ${r.role} <span style="color:var(--text-dim); margin-left:auto;">${r.worker.status}</span>
      </div>
    `).join('');
    legendList.querySelectorAll('.legend-item').forEach(el=>{
      el.addEventListener('click', ()=> SceneApp.focusOnRoleBot(el.dataset.role));
    });
  }

  // ---------------- persistent minimizable panels ----------------
  function makePanel(id, title, bodyHTML){
    const existing = document.getElementById(id);
    if (existing){ existing.querySelector('.panel-body').innerHTML = bodyHTML; return; }

    const div = document.createElement('div');
    div.className = 'panel';
    div.id = id;
    div.innerHTML = `
      <div class="panel-head">
        <span class="panel-title">${title}</span>
        <div class="panel-actions">
          <button class="panel-btn" data-act="min">–</button>
          <button class="panel-btn" data-act="close">✕</button>
        </div>
      </div>
      <div class="panel-body">${bodyHTML}</div>
    `;
    div.querySelector('[data-act="min"]').onclick = () => div.classList.toggle('minimized');
    div.querySelector('[data-act="close"]').onclick = () => div.remove();
    windowsContainer.appendChild(div);
  }

  function tickerRowsHTML(){
    return PRICE_BOARD.assets.map(a => `
      <div class="row">
        <span class="row-label">${a.symbol}</span>
        <span class="row-value ${a.change>=0?'pos':'neg'}">
          ${a.symbol.includes('BONK') ? a.price.toFixed(6) : a.price.toLocaleString(undefined,{maximumFractionDigits:2})}
          <span style="font-size:0.68rem; margin-left:4px;">${a.change>=0?'+':''}${(a.change||0).toFixed(2)}%</span>
        </span>
      </div>
    `).join('');
  }

  function alertsRowsHTML(){
    const alerts = [
      { token: 'NEW_PUMP_XYZ', mcap: '$1.2M', change: '+234%' },
      { token: 'RISING_DEF', mcap: '$890K', change: '+156%' },
      { token: 'FRESH_GHI', mcap: '$410K', change: '+88%' }
    ];
    return alerts.map(a => `
      <div class="row">
        <span class="row-label">${a.token} <span style="color:var(--text-dim)">· ${a.mcap}</span></span>
        <span class="row-value pos">${a.change}</span>
      </div>
    `).join('');
  }

  function startPersistentPanels(){
    makePanel('panel-ticker', '📈 LIVE PRICE TICKER', tickerRowsHTML());
    makePanel('panel-alerts', '⚡ MEME ALERTS', alertsRowsHTML());
    setInterval(()=>{
      PRICE_BOARD.tick();
      const p = document.getElementById('panel-ticker');
      if (p) p.querySelector('.panel-body').innerHTML = tickerRowsHTML();
    }, 2200);
  }

  // ---------------- modal helper ----------------
  function openModal(eyebrow, title, bodyHTML){
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="modalOverlay">
        <div class="modal-box">
          <div class="modal-head">
            <div>
              <div class="modal-eyebrow">${eyebrow}</div>
              <div class="modal-title">${title}</div>
            </div>
            <button class="modal-close" id="modalCloseBtn">✕</button>
          </div>
          <div class="modal-body">${bodyHTML}</div>
        </div>
      </div>
    `;
    document.getElementById('modalCloseBtn').onclick = closeModal;
    document.getElementById('modalOverlay').addEventListener('click', (e)=>{
      if (e.target.id === 'modalOverlay') closeModal();
    });
  }
  function closeModal(){ modalRoot.innerHTML = ''; }

  // ---------------- bot profile modal ----------------
  function openBotProfile(roleId){
    const role = ALL_ROLES.find(r => r.id === roleId);
    if (!role) return;
    const w = role.worker;

    openModal('WORKFORCE PROFILE', `${w.name} <span>· ${role.role}</span>`, `
      <div class="section">
        <div class="section-title">MANDATE</div>
        <div style="color:var(--text); line-height:1.5;">${role.mission}</div>
      </div>

      <div class="section">
        <div class="section-title">SHIFT</div>
        <div class="kv"><span class="kv-label">Shift Window</span><span class="kv-value">${w.shiftStart} – ${w.shiftEnd}</span></div>
        <div class="kv"><span class="kv-label">Status</span><span class="kv-value">${w.status}</span></div>
        <div class="kv"><span class="kv-label">Work Rate</span><span class="kv-value">${w.workRate}%</span></div>
      </div>

      <div class="section">
        <div class="section-title">TODAY'S PERFORMANCE</div>
        <div class="kv"><span class="kv-label">Trades Executed</span><span class="kv-value">${w.tradesToday}</span></div>
        <div class="kv"><span class="kv-label">Sales Volume</span><span class="kv-value">${fmtUSD(w.salesToday)}</span></div>
        <div class="kv"><span class="kv-label">P&amp;L Today</span><span class="kv-value ${w.pnlToday>=0?'':''}" style="color:${w.pnlToday>=0?'var(--green)':'var(--red)'}">${w.pnlToday>=0?'+':''}${fmtUSD(w.pnlToday)}</span></div>
      </div>

      <div class="hint">This is the individual worker's record. To reassign who staffs this role, close this panel and click the desk instead.</div>
    `);
  }

  // ---------------- desk / role settings modal ----------------
  function openDeskSettings(roleId){
    const role = ALL_ROLES.find(r => r.id === roleId);
    if (!role) return;

    openModal('ROLE CONFIGURATION', `${role.role} <span>· Desk Settings</span>`, `
      <div class="section">
        <div class="section-title">ROLE MANDATE</div>
        <div style="color:var(--text); line-height:1.5;">${role.mission}</div>
      </div>

      <div class="field">
        <label>Assigned Worker</label>
        <select id="workerSelect">
          <option>${role.worker.name} (current)</option>
          <option>Spin up new instance…</option>
        </select>
      </div>

      <div class="field">
        <label>Risk Per Trade</label>
        <input type="range" min="0.5" max="10" step="0.5" value="2" id="riskSlider">
      </div>

      <div class="field">
        <label>Max Position Size (USD)</label>
        <input type="number" value="2500" id="maxPos">
      </div>

      <div class="field">
        <label>Trading Pairs</label>
        <select id="pairsSelect">
          <option>Majors only (BTC, ETH, SOL)</option>
          <option>Majors + Meme coins</option>
          <option>Meme coins only</option>
        </select>
      </div>

      <div class="btn-row">
        <button class="btn" id="deskCancel">Cancel</button>
        <button class="btn btn-primary" id="deskSave">Save Role Settings</button>
      </div>
      <div class="hint">This changes the role's configuration — not the individual bot. To edit the worker itself, click that bot directly in the office.</div>
    `);
    document.getElementById('deskCancel').onclick = closeModal;
    document.getElementById('deskSave').onclick = () => {
      closeModal();
      flashToast(`${role.role} settings saved.`);
    };
  }

  // ---------------- chart board modal ----------------
  let chartInterval = null;
  function openChartBoard(){
    openModal('MARKET DATA WALL', `Live Feed <span>· Prices</span>`, `
      <div class="section">
        <div class="section-title">TRACKED ASSETS</div>
        <div id="chartRows">${tickerRowsHTML()}</div>
      </div>
      <div class="hint">Simulated feed for now — wire this up to a real market data API (e.g. CoinGecko for crypto, a metals API for gold) whenever you're ready.</div>
    `);
    if (chartInterval) clearInterval(chartInterval);
    chartInterval = setInterval(()=>{
      const el = document.getElementById('chartRows');
      if (!el){ clearInterval(chartInterval); return; }
      el.innerHTML = tickerRowsHTML();
    }, 1500);
  }

  // ---------------- world clock modal ----------------
  let clockInterval = null;
  function marketRowsHTML(){
    return MARKETS.map(m => {
      const open = isMarketOpen(m);
      return `
        <div class="row">
          <span class="row-label"><span class="market-dot ${open?'open':'closed'}"></span>${m.name}</span>
          <span class="row-value">${localTimeString(m.tz)}</span>
        </div>
      `;
    }).join('');
  }
  function openWorldClock(){
    openModal('GLOBAL MARKETS', `World Clock <span>· Trading Hours</span>`, `
      <div class="section">
        <div class="section-title">MARKET STATUS</div>
        <div id="marketRows">${marketRowsHTML()}</div>
      </div>
      <div class="hint">Green = market currently open, based on real local time and standard trading hours. Crypto markets never close.</div>
    `);
    if (clockInterval) clearInterval(clockInterval);
    clockInterval = setInterval(()=>{
      const el = document.getElementById('marketRows');
      if (!el){ clearInterval(clockInterval); return; }
      el.innerHTML = marketRowsHTML();
    }, 1000);
  }

  // ---------------- command core (boss overview) modal ----------------
  function openCommandCore(){
    const totalTrades = ROLES.reduce((s,r)=>s+r.worker.tradesToday,0);
    const totalPnl = ROLES.reduce((s,r)=>s+r.worker.pnlToday,0);
    const rows = ROLES.map(r=>`
      <div class="kv">
        <span class="kv-label">${r.role} — ${r.worker.name}</span>
        <span class="kv-value" style="color:${r.worker.workRate>=85?'var(--green)':'var(--amber)'}">${r.worker.workRate}% compliant</span>
      </div>
    `).join('');

    openModal('COMMAND CORE', `Floor Overview <span>· Boss Bot Audit</span>`, `
      <div class="section">
        <div class="section-title">FLOOR TOTALS</div>
        <div class="kv"><span class="kv-label">Total Trades Today</span><span class="kv-value">${totalTrades}</span></div>
        <div class="kv"><span class="kv-label">Net P&amp;L Today</span><span class="kv-value" style="color:${totalPnl>=0?'var(--green)':'var(--red)'}">${totalPnl>=0?'+':''}${fmtUSD(totalPnl)}</span></div>
      </div>
      <div class="section">
        <div class="section-title">ROLE COMPLIANCE (audited by BOSS BOT)</div>
        ${rows}
      </div>
      <div class="hint">BOSS BOT holds no trading mandate of its own — it exists to keep every other role inside its configured limits.</div>
    `);
  }

  // ---------------- wallet modal ----------------
  function openWallet(){
    const bal = WALLET.balances;
    const rows = Object.keys(bal).map(sym => `
      <div class="kv">
        <span class="kv-label">${sym}</span>
        <span class="kv-value">${bal[sym].toLocaleString(undefined,{maximumFractionDigits:4})} <span style="color:var(--text-dim)">(${fmtUSD(bal[sym]*WALLET.usdPrices[sym])})</span></span>
      </div>
    `).join('');

    openModal('TREASURY', `Office Wallet <span>· ${fmtUSD(WALLET.totalUSD())}</span>`, `
      <div class="section">
        <div class="section-title">CONNECT A PROVIDER</div>
        <div class="btn-row">
          <button class="btn" data-provider="phantom">👻 Phantom</button>
          <button class="btn" data-provider="coinbase">🪙 Coinbase</button>
          <button class="btn" data-provider="metamask">🦊 MetaMask</button>
        </div>
        <div class="status-line" style="margin-top:12px;">
          <span class="market-dot ${WALLET.connected?'open':'closed'}"></span>
          ${WALLET.connected ? `Connected via ${WALLET.provider}` : 'Not connected'}
        </div>
      </div>

      <div class="section">
        <div class="section-title">BALANCES</div>
        ${rows}
      </div>

      <div class="section">
        <div class="section-title">TOP UP</div>
        <div class="field">
          <label>Currency</label>
          <select id="topupCurrency">
            <option>SOL</option><option>BTC</option><option>ETH</option><option>USDC</option>
          </select>
        </div>
        <div class="field">
          <label>Amount</label>
          <input type="number" id="topupAmount" placeholder="0.00" min="0" step="0.01">
        </div>
        <button class="btn btn-primary" id="topupBtn" style="width:100%;">Add Funds</button>
      </div>
      <div class="hint">Wallet balances and top-ups are simulated locally. Swap in a real wallet adapter (Solana wallet-adapter, wagmi/ethers) to move real funds.</div>
    `);

    modalRoot.querySelectorAll('[data-provider]').forEach(btn=>{
      btn.onclick = () => {
        WALLET.connected = true;
        WALLET.provider = btn.dataset.provider;
        refreshHUD();
        openWallet();
      };
    });
    document.getElementById('topupBtn').onclick = () => {
      const cur = document.getElementById('topupCurrency').value;
      const amt = parseFloat(document.getElementById('topupAmount').value) || 0;
      if (amt > 0){
        WALLET.balances[cur] += amt;
        refreshHUD();
        openWallet();
        flashToast(`Added ${amt} ${cur} to the office wallet.`);
      }
    };
  }

  // ---------------- tiny toast ----------------
  function flashToast(msg){
    const t = document.createElement('div');
    t.textContent = msg;
    t.style.cssText = `
      position:fixed; bottom:26px; left:50%; transform:translateX(-50%);
      background:var(--panel); border:1px solid var(--cyan); color:var(--text);
      padding:10px 18px; border-radius:8px; font-family:var(--font-mono); font-size:0.78rem;
      z-index:3000; box-shadow:0 0 20px rgba(0,229,255,0.3);
    `;
    document.body.appendChild(t);
    setTimeout(()=> t.remove(), 2400);
  }

  // ---------------- wiring ----------------
  function bindEvents(){
    Bus.on('open-bot-profile', openBotProfile);
    Bus.on('open-desk-settings', openDeskSettings);
    Bus.on('open-chartboard', openChartBoard);
    Bus.on('open-worldclock', openWorldClock);
    Bus.on('open-command-core', openCommandCore);
    Bus.on('office-view', () => backBtn.classList.add('hidden'));

    document.getElementById('walletBtn').onclick = openWallet;

    // whenever the camera moves away from the office view, reveal "return" button
    ['open-bot-profile','open-desk-settings','open-chartboard','open-worldclock','open-command-core']
      .forEach(evt => Bus.on(evt, () => backBtn.classList.remove('hidden')));

    backBtn.onclick = () => { SceneApp.returnToOffice(); closeModal(); };
  }

  function init(){
    buildLegend();
    startPersistentPanels();
    refreshHUD();
    bindEvents();
    setInterval(refreshHUD, 3000);
  }

  return { init };
})();
