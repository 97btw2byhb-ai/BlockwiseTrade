/* =========================================================
   BLOCKWISE TRADE OFFICE — DATA LAYER
   Everything in this file is placeholder / simulated data.
   Swap the marked spots for real API calls / wallet SDKs later.
   ========================================================= */

// ---- tiny event bus so scene.js / ui.js can talk without tangling ----
const Bus = {
  handlers: {},
  on(evt, fn){ (this.handlers[evt] ||= []).push(fn); },
  emit(evt, payload){ (this.handlers[evt] || []).forEach(fn => fn(payload)); }
};

// ---- workforce roster -------------------------------------------------
// role: what the desk/role is for (assignable independent of the worker)
// worker: the individual bot currently staffing that role
const ROLES = [
  {
    id: 'trend',
    role: 'TREND BOT',
    mission: 'Identifies and rides multi-hour price trends across major pairs.',
    color: 0x00e5ff,
    hex: '#00e5ff',
    deskPos: [-9, 0, -4],
    worker: { name: 'TB-014', shiftStart: '00:00', shiftEnd: '08:00', tradesToday: 34, salesToday: 18240, pnlToday: 612.40, workRate: 91, status: 'ACTIVE' }
  },
  {
    id: 'buy',
    role: 'BUY BOT',
    mission: 'Executes buy-side entries the moment signal thresholds are met.',
    color: 0x39ff9d,
    hex: '#39ff9d',
    deskPos: [-4.5, 0, -4],
    worker: { name: 'BB-002', shiftStart: '08:00', shiftEnd: '16:00', tradesToday: 58, salesToday: 42110, pnlToday: 981.15, workRate: 88, status: 'ACTIVE' }
  },
  {
    id: 'finance',
    role: 'FINANCE BOT',
    mission: 'Reconciles balances, tracks exposure, and manages the treasury.',
    color: 0x60a5fa,
    hex: '#60a5fa',
    deskPos: [0, 0, -4],
    worker: { name: 'FB-101', shiftStart: '00:00', shiftEnd: '24:00', tradesToday: 0, salesToday: 0, pnlToday: 0, workRate: 97, status: 'ACTIVE' }
  },
  {
    id: 'risk',
    role: 'RISK BOT',
    mission: 'Caps position sizing and pulls the brake on runaway drawdowns.',
    color: 0xffb020,
    hex: '#ffb020',
    deskPos: [4.5, 0, -4],
    worker: { name: 'RB-007', shiftStart: '00:00', shiftEnd: '24:00', tradesToday: 4, salesToday: 0, pnlToday: -120.30, workRate: 95, status: 'ACTIVE' }
  },
  {
    id: 'meme',
    role: 'MEME BOT',
    mission: 'Hunts fresh meme-coin liquidity for high-risk, high-reward plays.',
    color: 0xff4dd8,
    hex: '#ff4dd8',
    deskPos: [9, 0, -4],
    worker: { name: 'MB-420', shiftStart: '16:00', shiftEnd: '24:00', tradesToday: 112, salesToday: 9870, pnlToday: 340.65, workRate: 76, status: 'ACTIVE' }
  }
];

const BOSS = {
  id: 'boss',
  role: 'BOSS BOT',
  mission: 'Owns no single strategy — supervises the floor, audits every role, and enforces that each bot stays inside its mandate.',
  color: 0xffd166,
  hex: '#ffd166',
  deskPos: [0, 0, 2.5],
  worker: { name: 'OVERSEER', shiftStart: '00:00', shiftEnd: '24:00', tradesToday: 0, salesToday: 0, pnlToday: 0, workRate: 100, status: 'SUPERVISING' }
};

// ---- world markets (real UTC-offset logic, not mocked) ----------------
// hours are in each market's local time
const MARKETS = [
  { name: 'New York (NYSE)', tz: 'America/New_York', open: 9.5, close: 16 },
  { name: 'London (LSE)',    tz: 'Europe/London',     open: 8,   close: 16.5 },
  { name: 'Frankfurt (DAX)', tz: 'Europe/Berlin',      open: 9,   close: 17.5 },
  { name: 'Tokyo (TSE)',     tz: 'Asia/Tokyo',         open: 9,   close: 15 },
  { name: 'Hong Kong (HKEX)',tz: 'Asia/Hong_Kong',     open: 9.5, close: 16 },
  { name: 'Crypto (Global)', tz: 'UTC', open: 0, close: 24, always: true }
];

function isMarketOpen(market){
  if (market.always) return true;
  const now = new Date();
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: market.tz, hour:'numeric', minute:'numeric', hour12:false, weekday:'short'
  }).formatToParts(now);
  const map = {};
  parts.forEach(p => map[p.type] = p.value);
  const weekday = map.weekday;
  if (weekday === 'Sat' || weekday === 'Sun') return false;
  const hour = parseInt(map.hour, 10) + parseInt(map.minute, 10) / 60;
  return hour >= market.open && hour < market.close;
}

function localTimeString(tz){
  return new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour:'2-digit', minute:'2-digit', second:'2-digit', hour12:false
  }).format(new Date());
}

// ---- price ticker (simulated random walk — replace with a real feed) --
// REAL-DATA HOOK: swap `tick()` internals for e.g. a fetch to
// https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd
const PRICE_BOARD = {
  assets: [
    { symbol: 'BTC/USD',  price: 64230.50 },
    { symbol: 'ETH/USD',  price: 3140.10 },
    { symbol: 'SOL/USD',  price: 142.75 },
    { symbol: 'XAU/USD',  price: 2385.20 }, // gold
    { symbol: 'BONK/SOL', price: 0.000021 }
  ],
  tick(){
    this.assets.forEach(a => {
      const drift = (Math.random() - 0.5) * (a.price * 0.006);
      a.price = Math.max(0.0000001, a.price + drift);
      a.change = (drift / a.price) * 100;
    });
    return this.assets;
  }
};

// ---- wallet (mock balances — replace with real wallet-adapter / ethers)
const WALLET = {
  connected: false,
  provider: null,
  balances: { SOL: 12.4, BTC: 0.081, ETH: 1.65, USDC: 8450 },
  usdPrices: { SOL: 142.75, BTC: 64230.5, ETH: 3140.1, USDC: 1 },
  totalUSD(){
    return Object.entries(this.balances)
      .reduce((sum, [k, v]) => sum + v * this.usdPrices[k], 0);
  }
};
