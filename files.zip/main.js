window.addEventListener('DOMContentLoaded', () => {
  const statusEl = document.getElementById('loadStatus');
  const messages = [
    'BOOTING WORKFORCE...',
    'CALIBRATING TREND BOT...',
    'ARMING BUY BOT...',
    'SYNCING FINANCE LEDGER...',
    'RISK BOT ONLINE...',
    'BOSS BOT TAKING ROLL CALL...'
  ];
  let i = 0;
  const statusTimer = setInterval(() => {
    i = (i + 1) % messages.length;
    if (statusEl) statusEl.textContent = messages[i];
  }, 420);

  SceneApp.init();

  setTimeout(() => {
    clearInterval(statusTimer);
    document.getElementById('loadingScreen').style.display = 'none';
    document.getElementById('hud').classList.remove('hidden');
    UI.init();
  }, 2700);
});
