/* =========================================================
   BLOCKWISE TRADE OFFICE — 3D SCENE
   Vanilla Three.js (r128). No build step required.
   ========================================================= */

const SceneApp = (() => {

  let renderer, scene, camera, clock3d;
  let desks = [], bots = [], interactables = [];
  let raycaster, mouse;
  let pointerDown = { x: 0, y: 0 };

  // camera framing
  const OFFICE_VIEW = { pos: new THREE.Vector3(0, 23, 21), look: new THREE.Vector3(0, 0, -2) };
  let camFrom = { pos: new THREE.Vector3(), look: new THREE.Vector3() };
  let camTo   = { pos: new THREE.Vector3(), look: new THREE.Vector3() };
  let camT = 1, camDuration = 1;
  let currentLook = OFFICE_VIEW.look.clone();
  let focused = false;

  let commandRing1, commandRing2;

  function init(){
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x05070f);
    scene.fog = new THREE.Fog(0x05070f, 26, 70);

    camera = new THREE.PerspectiveCamera(50, window.innerWidth/window.innerHeight, 0.1, 200);
    camera.position.copy(OFFICE_VIEW.pos);
    camera.lookAt(OFFICE_VIEW.look);

    renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('scene'), antialias:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    lights();
    buildFloor();
    buildWalls();
    buildDesksAndBots();
    buildBossPlatform();
    buildChartBoard();
    buildClockObject();
    buildAmbientDecor();

    raycaster = new THREE.Raycaster();
    mouse = new THREE.Vector2();

    window.addEventListener('resize', onResize);
    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);
    renderer.domElement.addEventListener('pointermove', onPointerMove);

    animate();
  }

  function lights(){
    scene.add(new THREE.AmbientLight(0x445577, 0.55));

    const key = new THREE.DirectionalLight(0x8fdcff, 0.8);
    key.position.set(10, 22, 10);
    key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048);
    scene.add(key);

    const cyanFill = new THREE.PointLight(0x00e5ff, 1.1, 40);
    cyanFill.position.set(-10, 8, 6);
    scene.add(cyanFill);

    const violetFill = new THREE.PointLight(0xa855f7, 1.0, 40);
    violetFill.position.set(10, 8, -8);
    scene.add(violetFill);
  }

  function buildFloor(){
    const floorMat = new THREE.MeshStandardMaterial({ color:0x0b0f1e, roughness:0.55, metalness:0.3 });
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), floorMat);
    floor.rotation.x = -Math.PI/2;
    floor.receiveShadow = true;
    scene.add(floor);

    const grid = new THREE.GridHelper(40, 40, 0x00e5ff, 0x142033);
    grid.material.opacity = 0.35;
    grid.material.transparent = true;
    scene.add(grid);

    // neon perimeter strip
    const stripGeo = new THREE.RingGeometry(18.6, 19, 64);
    const stripMat = new THREE.MeshBasicMaterial({ color:0x00e5ff, side:THREE.DoubleSide, transparent:true, opacity:0.5 });
    const strip = new THREE.Mesh(stripGeo, stripMat);
    strip.rotation.x = -Math.PI/2;
    strip.position.y = 0.02;
    scene.add(strip);
  }

  function buildWalls(){
    const wallMat = new THREE.MeshStandardMaterial({ color:0x090c18, roughness:0.75 });

    const back = new THREE.Mesh(new THREE.PlaneGeometry(40, 16), wallMat);
    back.position.set(0, 8, -16);
    scene.add(back);

    const left = new THREE.Mesh(new THREE.PlaneGeometry(40, 16), wallMat);
    left.rotation.y = Math.PI/2;
    left.position.set(-16, 8, 0);
    scene.add(left);

    const right = new THREE.Mesh(new THREE.PlaneGeometry(40, 16), wallMat);
    right.rotation.y = -Math.PI/2;
    right.position.set(16, 8, 0);
    scene.add(right);

    // ceiling accent grid (just lines, keeps top view readable)
    const ceilGridGeo = new THREE.BufferGeometry();
    const verts = [];
    for(let i=-16;i<=16;i+=4){
      verts.push(i,15.9,-16, i,15.9,16);
      verts.push(-16,15.9,i, 16,15.9,i);
    }
    ceilGridGeo.setAttribute('position', new THREE.Float32BufferAttribute(verts,3));
    const ceilGrid = new THREE.LineSegments(ceilGridGeo, new THREE.LineBasicMaterial({ color:0x00e5ff, transparent:true, opacity:0.18 }));
    scene.add(ceilGrid);
  }

  function makeBot(color, scale=1){
    const g = new THREE.Group();

    const bodyMat = new THREE.MeshStandardMaterial({ color:0x161c2c, emissive:color, emissiveIntensity:0.25, metalness:0.85, roughness:0.25 });
    const accentMat = new THREE.MeshStandardMaterial({ color:color, emissive:color, emissiveIntensity:0.9, metalness:0.6, roughness:0.2 });

    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.45,0.55,1.5,8), bodyMat);
    torso.position.y = 1.2;
    torso.castShadow = true;
    g.add(torso);

    const chestLight = new THREE.Mesh(new THREE.CircleGeometry(0.18,24), accentMat);
    chestLight.position.set(0,1.35,0.5);
    g.add(chestLight);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.4,24,24), bodyMat);
    head.position.y = 2.15;
    head.castShadow = true;
    g.add(head);

    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.5,0.12,0.06), accentMat);
    visor.position.set(0, 2.18, 0.36);
    g.add(visor);

    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.02,0.02,0.4,6), bodyMat);
    antenna.position.set(0, 2.75, 0);
    g.add(antenna);
    const antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.06,12,12), accentMat);
    antennaTip.position.set(0, 2.98, 0);
    g.add(antennaTip);

    // arms
    [-0.62, 0.62].forEach(x=>{
      const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.09,0.09,1.0,8), bodyMat);
      arm.position.set(x, 1.25, 0);
      g.add(arm);
    });

    // legs / base
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.5,0.4,0.5,10), bodyMat);
    base.position.y = 0.28;
    g.add(base);

    g.scale.setScalar(scale);
    g.userData.eyeAccent = accentMat;
    return g;
  }

  function buildDesksAndBots(){
    ROLES.forEach(role => {
      const [x,y,z] = role.deskPos;

      // desk
      const deskGroup = new THREE.Group();
      const deskMat = new THREE.MeshStandardMaterial({ color:0x1b2438, roughness:0.5, metalness:0.4 });
      const top = new THREE.Mesh(new THREE.BoxGeometry(2.6,0.12,1.4), deskMat);
      top.position.y = 0.9;
      top.castShadow = true; top.receiveShadow = true;
      deskGroup.add(top);
      const leg = new THREE.Mesh(new THREE.BoxGeometry(2.4,0.9,1.2), new THREE.MeshStandardMaterial({ color:0x0e1420 }));
      leg.position.y = 0.45;
      deskGroup.add(leg);

      const monitor = new THREE.Mesh(
        new THREE.BoxGeometry(1.5,1.0,0.06),
        new THREE.MeshStandardMaterial({ color:0x05070f, emissive:role.color, emissiveIntensity:0.6 })
      );
      monitor.position.set(0, 1.55, -0.5);
      deskGroup.add(monitor);

      deskGroup.position.set(x,y,z);
      deskGroup.userData = { type:'desk', roleId: role.id };
      scene.add(deskGroup);
      interactables.push(deskGroup);
      desks.push({ group: deskGroup, role });

      // bot behind desk
      const bot = makeBot(role.color);
      bot.position.set(x, 0, z - 1.3);
      bot.rotation.y = Math.PI;
      bot.userData = { type:'bot', roleId: role.id };
      scene.add(bot);
      interactables.push(bot);
      bots.push({ group: bot, role });
    });
  }

  function buildBossPlatform(){
    const [x,y,z] = BOSS.deskPos;
    const platform = new THREE.Mesh(
      new THREE.CylinderGeometry(2.3,2.3,0.35,32),
      new THREE.MeshStandardMaterial({ color:0x1a1530, emissive:0xffd166, emissiveIntensity:0.25, metalness:0.7, roughness:0.3 })
    );
    platform.position.set(x, 0.17, z);
    platform.receiveShadow = true;
    scene.add(platform);

    const bossBot = makeBot(BOSS.color, 1.25);
    bossBot.position.set(x, 0.35, z);
    bossBot.userData = { type:'bot', roleId:'boss' };
    scene.add(bossBot);
    interactables.push(bossBot);
    bots.push({ group: bossBot, role: BOSS });

    // signature element — rotating holographic command core above boss
    const ringGeo1 = new THREE.TorusGeometry(1.5, 0.02, 8, 64);
    const ringMat1 = new THREE.MeshBasicMaterial({ color:0x00e5ff, transparent:true, opacity:0.75 });
    commandRing1 = new THREE.Mesh(ringGeo1, ringMat1);
    commandRing1.rotation.x = Math.PI/2;
    commandRing1.position.set(x, 3.6, z);
    scene.add(commandRing1);

    const ringGeo2 = new THREE.TorusGeometry(1.1, 0.015, 8, 64);
    const ringMat2 = new THREE.MeshBasicMaterial({ color:0xa855f7, transparent:true, opacity:0.75 });
    commandRing2 = new THREE.Mesh(ringGeo2, ringMat2);
    commandRing2.rotation.x = Math.PI/2.6;
    commandRing2.position.set(x, 3.6, z);
    scene.add(commandRing2);

    const core = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.32, 0),
      new THREE.MeshStandardMaterial({ color:0xffd166, emissive:0xffd166, emissiveIntensity:1.2, wireframe:false })
    );
    core.position.set(x, 3.6, z);
    core.userData = { type:'commandcore' };
    scene.add(core);
    interactables.push(core);
    commandRing1.userData.core = core;
  }

  function buildChartBoard(){
    const frame = new THREE.Mesh(
      new THREE.BoxGeometry(6, 3.4, 0.15),
      new THREE.MeshStandardMaterial({ color:0x0a0d18, emissive:0x00e5ff, emissiveIntensity:0.35, metalness:0.6, roughness:0.3 })
    );
    frame.position.set(-9, 6.2, -15.9);
    frame.userData = { type:'chartboard' };
    scene.add(frame);
    interactables.push(frame);

    const label = document.createElement('div'); // (kept for future CSS3DRenderer upgrade)
    label.remove();
  }

  function buildClockObject(){
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(1.3, 0.08, 12, 48),
      new THREE.MeshStandardMaterial({ color:0x1b2438, emissive:0xffd166, emissiveIntensity:0.6, metalness:0.6 })
    );
    ring.position.set(9, 6.5, -15.85);
    ring.userData = { type:'clock' };
    scene.add(ring);
    interactables.push(ring);

    const face = new THREE.Mesh(
      new THREE.CircleGeometry(1.15, 32),
      new THREE.MeshStandardMaterial({ color:0x05070f, emissive:0xffd166, emissiveIntensity:0.15 })
    );
    face.position.set(9, 6.5, -15.8);
    scene.add(face);
  }

  function buildAmbientDecor(){
    // a few floating data pillars for atmosphere
    const positions = [[-14,0,8],[14,0,9],[-6,0,7],[6,0,7]];
    positions.forEach(([x,y,z])=>{
      const h = 1.5 + Math.random()*2;
      const pillar = new THREE.Mesh(
        new THREE.BoxGeometry(0.5,h,0.5),
        new THREE.MeshStandardMaterial({ color:0x101828, emissive:0x00e5ff, emissiveIntensity:0.3 })
      );
      pillar.position.set(x, h/2, z);
      scene.add(pillar);
    });
  }

  // ---------------- camera tween ----------------
  function focusOn(targetPos, targetLook, duration=1.0){
    camFrom.pos.copy(camera.position);
    camFrom.look.copy(currentLook);
    camTo.pos.copy(targetPos);
    camTo.look.copy(targetLook);
    camT = 0; camDuration = duration;
    focused = true;
  }

  function returnToOffice(duration=1.0){
    focusOn(OFFICE_VIEW.pos, OFFICE_VIEW.look, duration);
    focused = false;
    Bus.emit('office-view');
  }

  function easeInOutCubic(t){ return t<0.5 ? 4*t*t*t : 1-Math.pow(-2*t+2,3)/2; }

  function updateCameraTween(dt){
    if (camT < 1){
      camT = Math.min(1, camT + dt/camDuration);
      const e = easeInOutCubic(camT);
      camera.position.lerpVectors(camFrom.pos, camTo.pos, e);
      currentLook.lerpVectors(camFrom.look, camTo.look, e);
      camera.lookAt(currentLook);
    }
  }

  // ---------------- interaction ----------------
  function onPointerDown(e){ pointerDown.x = e.clientX; pointerDown.y = e.clientY; }

  function onPointerMove(e){
    mouse.x = (e.clientX/window.innerWidth)*2 - 1;
    mouse.y = -(e.clientY/window.innerHeight)*2 + 1;
  }

  function onPointerUp(e){
    const moved = Math.hypot(e.clientX - pointerDown.x, e.clientY - pointerDown.y);
    if (moved > 6) return; // was a drag, not a click

    raycaster.setFromCamera(mouse, camera);
    const hits = raycaster.intersectObjects(interactables, true);
    if (!hits.length) return;

    let obj = hits[0].object;
    while (obj && !obj.userData.type) obj = obj.parent;
    if (!obj) return;

    handleClick(obj);
  }

  function worldPos(group){
    const p = new THREE.Vector3();
    group.getWorldPosition(p);
    return p;
  }

  function handleClick(obj){
    const { type, roleId } = obj.userData;

    if (type === 'bot'){
      const p = worldPos(obj);
      focusOn(new THREE.Vector3(p.x + 2.4, p.y + 2.2, p.z + 3.2), new THREE.Vector3(p.x, p.y+1.4, p.z));
      Bus.emit('open-bot-profile', roleId);
    }
    else if (type === 'desk'){
      const p = worldPos(obj);
      focusOn(new THREE.Vector3(p.x, p.y + 3.2, p.z + 4.2), new THREE.Vector3(p.x, p.y+0.5, p.z));
      Bus.emit('open-desk-settings', roleId);
    }
    else if (type === 'chartboard'){
      const p = worldPos(obj);
      focusOn(new THREE.Vector3(p.x, p.y, p.z + 6), new THREE.Vector3(p.x, p.y, p.z));
      Bus.emit('open-chartboard');
    }
    else if (type === 'clock'){
      const p = worldPos(obj);
      focusOn(new THREE.Vector3(p.x, p.y, p.z + 6), new THREE.Vector3(p.x, p.y, p.z));
      Bus.emit('open-worldclock');
    }
    else if (type === 'commandcore'){
      const p = worldPos(obj);
      focusOn(new THREE.Vector3(p.x + 3, p.y + 1.5, p.z + 3), new THREE.Vector3(p.x, p.y, p.z));
      Bus.emit('open-command-core');
    }
  }

  function onResize(){
    camera.aspect = window.innerWidth/window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function animate(){
    requestAnimationFrame(animate);
    const dt = 0.016;

    updateCameraTween(dt);

    bots.forEach(b => { b.group.rotation.y += focused ? 0 : 0.0025; });
    if (commandRing1){
      commandRing1.rotation.z += 0.01;
      commandRing2.rotation.z -= 0.014;
      commandRing1.userData.core.rotation.y += 0.02;
    }

    renderer.render(scene, camera);
  }

  function focusOnRoleBot(roleId){
    const b = bots.find(b => b.role.id === roleId);
    if (!b) return;
    handleClick(b.group);
  }

  return { init, returnToOffice, focusOnRoleBot };
})();
