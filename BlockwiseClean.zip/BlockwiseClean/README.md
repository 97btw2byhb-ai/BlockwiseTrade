# BlockWise — Automated Trading Office & Learning Platform

**Trade. Learn. Automate.**

BlockWise is a non-custodial trading platform that combines structured education with bot-driven automation. Users learn in a risk-free simulation environment, then transition to real automated trading when ready.

## Features

- **Trading Office**: Visual dashboard with bots (Buy Bot, Sniper, Finance Bot, Boss Bot), positions, activity feed, and rooms for oversight, trading floor, finance, and learning.
- **Academy**: 12 progressive modules (Beginner → Intermediate → Pro) covering fundamentals, bot building, risk management, and multi-bot orchestration.
- **Simulation Mode**: Practice strategies with no live orders or custody.
- **Automation Mode**: Bot-led workflows for sourcing, execution, and reporting (non-custodial — keys stay with the user).
- **Community**: Leaderboards, challenges, and optional pooled strategies.
- **Integrations**: Phantom, Coinbase, MetaMask, WalletConnect, Telegram (read-only where noted).

## Live Demo

The polished version matching this codebase is deployed at:  
https://topaz-island-willow-cabin.grok.me/

## Repository Structure

```
/
├── index.html          # Main single-file SPA (landing + modules view via hash routing)
├── README.md           # This file
├── .gitignore
└── .github/workflows/  # (optional) GitHub Pages deployment
```

## Local Development

1. Clone the repo.
2. Open `index.html` in a browser, or serve it:
   ```bash
   python3 -m http.server 8000
   ```
3. Visit `http://localhost:8000`

## Deployment

### GitHub Pages
- Push to `main` (or the branch with the Pages workflow).
- Enable GitHub Pages from the repository root.
- Site will be available at `https://<username>.github.io/BlockwiseTrade/`

### Other hosts
The site is a self-contained HTML file with inline CSS and JS. It can be hosted on any static host (Netlify, Vercel, Cloudflare Pages, etc.).

## Tech Stack

- Pure HTML5 + CSS3 + vanilla JavaScript (single file for simplicity)
- Responsive design
- Hash-based routing for Academy/modules view
- Non-custodial by design (no private key handling in the frontend)

## Status

- Landing page & Academy curriculum: Live
- Office view / live bots: In final build (early access)
- Simulation: Open
- Real automation tooling: Available to eligible members

## Community

Join the Telegram group for early access, setup help, and updates:  
https://t.me/Blockwisev1

---

*Disclaimer: Trading involves substantial risk of loss. This is not financial advice. BlockWise is a learning and automation tool — users retain full control of their funds.*
